# This file is a part of Julia. License is MIT: https://julialang.org/license

module X3Tests

using x2

println("hello")

end # module
