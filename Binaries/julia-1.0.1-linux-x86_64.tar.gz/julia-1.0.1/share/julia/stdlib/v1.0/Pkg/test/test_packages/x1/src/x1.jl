# This file is a part of Julia. License is MIT: https://julialang.org/license

module x1

greet() = print("Hello World!")

end # module
