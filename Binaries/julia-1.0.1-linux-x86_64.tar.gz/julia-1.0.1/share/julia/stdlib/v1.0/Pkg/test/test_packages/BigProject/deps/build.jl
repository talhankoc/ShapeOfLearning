# This file is a part of Julia. License is MIT: https://julialang.org/license

using SubModule
using SubModule2

touch(joinpath(@__DIR__, "buildartifact"))
