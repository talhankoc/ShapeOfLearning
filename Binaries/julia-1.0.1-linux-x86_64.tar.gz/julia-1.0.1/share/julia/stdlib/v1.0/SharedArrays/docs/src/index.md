# Shared Arrays

```@docs
SharedArrays.SharedArray
SharedArrays.procs(::SharedArray)
SharedArrays.sdata
SharedArrays.indexpids
SharedArrays.localindices
```
